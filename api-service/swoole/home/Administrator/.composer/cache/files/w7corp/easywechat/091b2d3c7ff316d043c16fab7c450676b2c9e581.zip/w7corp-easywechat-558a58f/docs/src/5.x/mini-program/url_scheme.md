# URL Scheme

> 微信文档：https://developers.weixin.qq.com/miniprogram/dev/api-backend/open-api/url-scheme/urlscheme.generate.html

> tips: 目前仅针对国内非个人主体的小程序开放.

## 获取小程序scheme码

```php
$app->url_scheme->generate();
```