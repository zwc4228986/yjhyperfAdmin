<?php

declare(strict_types=1);

namespace EasyWeChat\Kernel\Exceptions;

class InvalidArgumentException extends Exception
{
}
