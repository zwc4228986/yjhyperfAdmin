<?php

declare(strict_types=1);

namespace EasyWeChat\MiniApp;

use EasyWeChat\MiniApp\Contracts\Account as AccountInterface;

class Account extends \EasyWeChat\OfficialAccount\Account implements AccountInterface
{
    //
}
