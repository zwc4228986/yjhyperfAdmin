<?php

declare(strict_types=1);

namespace EasyWeChat\MiniApp;

class AccessToken extends \EasyWeChat\OfficialAccount\AccessToken
{
    //
}
