<template>
  <sup
    class="bg-green-500 text-xs text-white px-2 py-1 rounded-lg align-top rounded-bl-none"
    title="该特性需要更新到此版本可用"
    ><slot
  /></sup>
</template>
