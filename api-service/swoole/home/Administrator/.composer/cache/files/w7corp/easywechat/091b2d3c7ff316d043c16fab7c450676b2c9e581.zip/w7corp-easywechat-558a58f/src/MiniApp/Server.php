<?php

declare(strict_types=1);

namespace EasyWeChat\MiniApp;

class Server extends \EasyWeChat\OfficialAccount\Server
{
}
