# 自动回复

## 获取当前设置的回复规则

```php
$app->auto_reply->current();
```