# 服务端

小程序的服务端推送和公众号一样，请参考：[公众号：服务端](../official-account/server.md)