<?php

namespace EasyWeChat\Kernel\Exceptions;

class BadMethodCallException extends Exception
{
}
