<?php

declare(strict_types=1);

namespace EasyWeChat\Kernel\Exceptions;

class RuntimeException extends Exception
{
}
