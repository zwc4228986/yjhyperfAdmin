<?php

declare(strict_types=1);

namespace EasyWeChat\OpenWork;

/**
 * @property string $InfoType
 * @property string $ChangeType
 * @property string $SuiteTicket
 * @property string $SuiteId
 * @property string $MsgType
 * @property string $Event
 */
class Message extends \EasyWeChat\Kernel\Message
{
    //
}
