# 图片上传
上传证件照片。支持 jpeg、jpg、bmp、png 格式，图片大小不超过2M。

```php
// $path string 图片路径
$response = $app->media->upload($path);
```
