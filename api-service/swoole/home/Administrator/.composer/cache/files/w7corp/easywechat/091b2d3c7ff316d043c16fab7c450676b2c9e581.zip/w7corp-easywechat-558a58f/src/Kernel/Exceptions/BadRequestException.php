<?php

declare(strict_types=1);

namespace EasyWeChat\Kernel\Exceptions;

class BadRequestException extends Exception
{
}
