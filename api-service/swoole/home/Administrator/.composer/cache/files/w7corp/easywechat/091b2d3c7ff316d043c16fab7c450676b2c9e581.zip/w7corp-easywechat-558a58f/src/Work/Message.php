<?php

declare(strict_types=1);

namespace EasyWeChat\Work;

/**
 * @property string $Event
 * @property string $InfoType
 * @property string $MsgType
 * @property string $ChangeType
 */
class Message extends \EasyWeChat\Kernel\Message
{
    //
}
