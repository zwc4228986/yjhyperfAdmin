# 事件



更多请参考：[服务端](server.html)

关于事件类型请参考微信官方文档：http://mp.weixin.qq.com/wiki/
