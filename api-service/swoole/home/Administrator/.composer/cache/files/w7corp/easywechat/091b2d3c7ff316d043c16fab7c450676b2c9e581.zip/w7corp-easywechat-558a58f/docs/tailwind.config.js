module.exports = {
  darkMode: 'class',
  theme: {
    extend: {}
  },
  variants: {},
  plugins: [],
  content: [
    './src/**/*.md',
    './.vitepress/theme/components/*.vue',
    './.vitepress/theme/styles/*.scss',
  ],
}
