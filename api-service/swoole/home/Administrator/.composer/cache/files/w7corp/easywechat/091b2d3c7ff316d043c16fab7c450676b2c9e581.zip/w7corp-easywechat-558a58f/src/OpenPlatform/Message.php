<?php

declare(strict_types=1);

namespace EasyWeChat\OpenPlatform;

/**
 * @property string $InfoType
 * @property string $ComponentVerifyTicket
 */
class Message extends \EasyWeChat\Kernel\Message
{
    //
}
