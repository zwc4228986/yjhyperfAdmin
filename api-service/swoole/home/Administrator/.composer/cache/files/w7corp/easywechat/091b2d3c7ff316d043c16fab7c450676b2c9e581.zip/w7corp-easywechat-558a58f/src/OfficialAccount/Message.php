<?php

declare(strict_types=1);

namespace EasyWeChat\OfficialAccount;

/**
 * @property string $Event
 * @property string $MsgType
 */
class Message extends \EasyWeChat\Kernel\Message
{
    //
}
