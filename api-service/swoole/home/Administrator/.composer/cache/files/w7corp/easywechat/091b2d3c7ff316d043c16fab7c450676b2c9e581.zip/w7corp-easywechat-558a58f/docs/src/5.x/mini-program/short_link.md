# Short Link

> 微信文档：https://developers.weixin.qq.com/miniprogram/dev/api-backend/open-api/short-link/shortlink.generate.html


## 获取小程序 Short Link

```php
$app->short_link->getShortLink(string $pageUrl, string $pageTitle, bool $isPermanent = false);
```