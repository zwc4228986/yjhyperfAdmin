# 手机号

> 微信文档：https://developers.weixin.qq.com/miniprogram/dev/api-backend/open-api/phonenumber/phonenumber.getPhoneNumber.html


## 获取手机号


```php
$app->phone_number->getUserPhoneNumber(string $code);
```