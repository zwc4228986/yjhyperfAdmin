# URL Link

> 微信文档：https://developers.weixin.qq.com/miniprogram/dev/api-backend/open-api/url-link/urllink.generate.html

> tips: 目前仅针对国内非个人主体的小程序开放.

## 获取小程序 URL Link

```php
$app->url_link->generate(array $params);
```