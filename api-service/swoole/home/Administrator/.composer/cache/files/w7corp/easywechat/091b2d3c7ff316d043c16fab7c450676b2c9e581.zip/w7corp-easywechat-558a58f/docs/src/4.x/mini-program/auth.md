# 微信登录

## 根据 jsCode 获取用户 session 信息

API:

```php
$app->auth->session(string $code);
```
