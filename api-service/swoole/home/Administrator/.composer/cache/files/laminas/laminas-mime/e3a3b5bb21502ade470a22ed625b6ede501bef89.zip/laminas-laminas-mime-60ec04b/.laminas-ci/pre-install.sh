#!/bin/bash

# Temporary workaround for cyclic dependencies - can be removed once 3.0 has been released

echo "Branch as 2.99.x in Pre-Install"

git checkout -b 2.99.x
