# Swoole Engine

![Swoole Engine Test](https://github.com/hyperf/engine/workflows/Swoole%20Engine%20Test/badge.svg)

```
composer require hyperf/engine
```
