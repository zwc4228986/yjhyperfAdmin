# Contract for Coroutine Engine

[![PHPUnit](https://github.com/hyperf/engine-contract/actions/workflows/test.yml/badge.svg)](https://github.com/hyperf/engine-contract/actions/workflows/test.yml)

## How to install

```
composer require hyperf/engine-contract
```
