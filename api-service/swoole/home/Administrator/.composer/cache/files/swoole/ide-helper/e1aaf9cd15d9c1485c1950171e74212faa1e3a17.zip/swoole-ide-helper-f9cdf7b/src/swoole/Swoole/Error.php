<?php

declare(strict_types=1);

namespace Swoole;

/**
 * This class is not yet in use anywhere in Swoole.
 *
 * @since 4.4.0
 */
class Error extends \Error
{
}
