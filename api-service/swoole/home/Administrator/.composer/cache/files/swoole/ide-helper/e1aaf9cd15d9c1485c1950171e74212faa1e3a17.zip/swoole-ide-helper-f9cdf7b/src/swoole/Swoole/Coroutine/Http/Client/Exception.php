<?php

declare(strict_types=1);

namespace Swoole\Coroutine\Http\Client;

/**
 * This class is not yet in use anywhere in Swoole.
 *
 * @alias This class has an alias of "\Co\Http\Client\Exception" when directive "swoole.use_shortname" is not explicitly turned off.
 * @see \Co\Http\Client\Exception
 * @since 4.5.8
 */
class Exception extends \Swoole\Exception
{
}
