<?php

declare(strict_types=1);

namespace Swoole\Client;

class Exception extends \Swoole\Exception
{
}
