<?php

declare(strict_types=1);

namespace Swoole\Http;

/**
 * The Http Server class.
 *
 * @not-serializable Objects of this class cannot be serialized.
 */
class Server extends \Swoole\Server
{
}
