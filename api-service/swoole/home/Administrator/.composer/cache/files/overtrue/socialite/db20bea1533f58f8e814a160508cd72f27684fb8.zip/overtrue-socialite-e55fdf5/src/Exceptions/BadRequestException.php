<?php

namespace Overtrue\Socialite\Exceptions;

class BadRequestException extends Exception
{
}
