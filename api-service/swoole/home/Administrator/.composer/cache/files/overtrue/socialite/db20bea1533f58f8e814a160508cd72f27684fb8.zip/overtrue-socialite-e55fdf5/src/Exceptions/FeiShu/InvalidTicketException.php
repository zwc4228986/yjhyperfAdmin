<?php

namespace Overtrue\Socialite\Exceptions\FeiShu;

use Overtrue\Socialite\Exceptions;

class InvalidTicketException extends Exceptions\Exception
{
}
